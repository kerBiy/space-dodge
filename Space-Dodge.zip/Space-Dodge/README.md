I don't fucking know what to say here so I will just speat facts, no less top G. 
This is my blulshit game so I hope you enjoy it.